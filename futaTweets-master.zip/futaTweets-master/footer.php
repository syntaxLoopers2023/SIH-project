<footer>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6 col-md-push-3 footerBlock" style="padding:0px;">
                <div class="container-fluid" id="about">
                    <div class="row" style="background-image:url(Img/naturalblack.png)">
                        
                        <div class="col-md-8 col-xs-10" style="padding-left:30px;padding-bottom:0px;">

                            <p>&copy; Team Syntex Loopers 2023</p>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>


</footer>
