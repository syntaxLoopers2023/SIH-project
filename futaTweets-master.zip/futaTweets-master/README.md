# futaTweets
Smallest Twitter-like Social Network Using HTML, CSS, BOOTSTRAP, PHP, and AJAX

Config Database with database/dbConfig.php

Import Table into database with: database/futatweets.sql

@RitcheyDevs
