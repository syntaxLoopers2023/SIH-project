import random


quotes=["Recycling is an investment in the future we will leave to the next generation.",
    "When you put the 'can' in the recycling bin, you're putting a 'yes' in the future.",
    "Recycling turns things into other things, which is like magic.",
    "Recycling is a simple act with huge benefits for our environment and future.",
    "Waste not, want not. Recycle today for a better tomorrow.",
    "The greatest threat to our planet is the belief that someone else will save it. Be the change, recycle.",
    "Recycling is not just a choice, it's a responsibility we all share.",
    "Every day is Earth Day when you recycle.",
    "Recycling: Because there is no Planet B.",
    "Don't trash our future. Recycle it.",
    "Recycling is the right thing to do, and it's easier than you think.",
    "One person's trash is another person's treasure – through recycling.",
];

random_quote = random.choice(quotes)

